-------------------------
Paypal Advanced Payment Gateway for Woocommerce
Author: Buif.Dw
Support: support@browsepress.com


Installing

1. Purchase and download the plugin zip file from: http://codecanyon.net
2. Login to your WordPress Admin. Click on Plugins | Add New from the left hand menu
3. Click on the “Upload” option, then click “Browse” to select the zip file from your computer. Once selected, press “OK” and press the “Install Now” button.
4. Activate the plugin.
5. Open the settings page for WooCommerce and click the “Payment Gateways” tab
6. Click on the sub tab for “PayPal Advanced”
7. Configure your PayPal Advanced settings.

Thank you for purchase.
Sincerely,
support@browsepress.com
